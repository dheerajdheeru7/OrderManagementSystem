﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using OrderManagementAPI.Models;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
namespace OrderManagementAPI.Controllers
{
    public class OrderController : ApiController
    {

        private List<Order> GetOrders(int userid)
        {
            List<Order> orders = new List<Order>();
            using (SqlConnection con = new SqlConnection(ConfigurationSettings.AppSettings["OrderManagementConn"].ToString()))
            {

                DataSet ds = new DataSet();
                SqlDataAdapter sda = new SqlDataAdapter("exec USP_GetOrders "+userid, con);
                sda.Fill(ds);
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    orders.Add(new Order()
                    {
                        OrderId = Convert.ToInt32(dr[0]),
                        UserId = Convert.ToInt32(dr[1]),
                        OrderedDate = Convert.ToDateTime(dr[2]),
                        OrderStatus = Convert.ToString(dr[3]),
                        ShippingAddress = Convert.ToString(dr[4]),                       
                        OrderItems=GlobalOperations.ConvertDataTable<OrderItem>(ds.Tables[1].Select("orderid="+Convert.ToInt32(dr[0])).CopyToDataTable())
                    });
                }

            }
            return orders;
        }

        // GET api/order
        public IEnumerable<Order> Get()
        {
            
            return GetOrders(0);
        }

        // GET api/order/5
        public IEnumerable<Order> Get(int id)
        {
            return GetOrders(id);
        }

        // POST api/order
        public HttpResponseMessage Post([FromBody]Order order)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(ConfigurationSettings.AppSettings["OrderManagementConn"].ToString()))
                {
                    con.Open();
                    SqlCommand cmd; 
                    //inserting an order and get an orderid
                    cmd = new SqlCommand();
                    cmd.CommandText = "USP_InsertOrder";
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@UserId", order.UserId);
                    cmd.Parameters.AddWithValue("@ShippingAddress", order.ShippingAddress);
                    int orderid = Convert.ToInt32(cmd.ExecuteScalar());
                    // end inserting an order and get an orderid

                    // inserting order items based on order inserted above
                    foreach (OrderItem oi in order.OrderItems)

                    {
                        cmd = new SqlCommand();
                        cmd.CommandText = "USP_InsertOrderItem";
                        cmd.Connection = con;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@OrderId", orderid);
                        cmd.Parameters.AddWithValue("@ProductId", oi.ItemId);
                        cmd.Parameters.AddWithValue("@Quantity", oi.Quantity);
                        cmd.ExecuteNonQuery();
                    }
                    con.Close();
                    if (orderid > 0)
                    {
                        SendEmail(order.UserId, orderid);     
                        return Request.CreateResponse(HttpStatusCode.OK);
            
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Order Id " + orderid + "Does not exist");
                    }
                    // inserting order items based on order inserted above
                    
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
        }

        private void SendEmail(int userid, int orderid)
        {

            
        }

        // PUT api/order/5
        public HttpResponseMessage Put(int id, [FromBody]Order order)
        {
            try
            {

            using (SqlConnection con = new SqlConnection(ConfigurationSettings.AppSettings["OrderManagementConn"].ToString()))
            {
                con.Open();
                SqlCommand cmd;
                //Updating an order
                cmd = new SqlCommand();
                cmd.CommandText = "USP_UpdateOrder";
                cmd.Connection = con;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@OrderId", id);
                cmd.Parameters.AddWithValue("@ShippingAddress", order.ShippingAddress);
               int updated= cmd.ExecuteNonQuery();
                // end Updating an order 

                // updating order items based on orderid 
                foreach (OrderItem oi in order.OrderItems)
                {
                    cmd = new SqlCommand();
                    cmd.CommandText = "USP_UpdateOrderItem";
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@OrderId", id);
                    cmd.Parameters.AddWithValue("@ProductId", oi.ItemId);
                    cmd.Parameters.AddWithValue("@Quantity", oi.Quantity);
                    cmd.ExecuteNonQuery();
                }
                // updating order items based on orderid
                con.Close();
                if(updated>0)
                {
                     return Request.CreateResponse(HttpStatusCode.OK);
                }
                else
                {
                   return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Order" + order + "is not updated");
                }
                
            }
        }
            catch(Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ex);
            }
            }
        // DELETE api/order/5
        public HttpResponseMessage Delete(int id)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(ConfigurationSettings.AppSettings["OrderManagementConn"].ToString()))
                {
                    con.Open();
                    SqlCommand cmd;
                    //delete an order  
                    cmd = new SqlCommand();
                    cmd.CommandText = "USP_DeleteOrder";
                    cmd.Connection = con;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@OrderId", id);
                    int deleted = cmd.ExecuteNonQuery();
                    // end delete an order 

                    con.Close();
                    if (deleted > 0)
                    {
                        return Request.CreateResponse(HttpStatusCode.OK);
                    }
                    else
                    {
                        return Request.CreateErrorResponse(HttpStatusCode.NotFound, "Order " + id + " No Found");
                    }
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest,ex);
            }
        }
    }
}
