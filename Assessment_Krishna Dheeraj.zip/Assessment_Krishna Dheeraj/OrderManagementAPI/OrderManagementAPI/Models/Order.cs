﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrderManagementAPI.Models
{
    public class Order
    {
        #region Private Variables
        private int _orderid;
        private int _userid;
        private DateTime _ordereddate;
        private string _orderstatus;
        private string _shippingaddress;
        private List<OrderItem> _orderitems;
        #endregion

        #region Public Properties
        public int OrderId
        {
            get { return _orderid; }
            set { _orderid = value; }
        }
        public int UserId
        {
            get { return _userid; }
            set { _userid = value; }
        }
        public DateTime OrderedDate
        {
            get { return _ordereddate; }
            set { _ordereddate = value; }
        }
        public string OrderStatus
        {
            get { return _orderstatus; }
            set { _orderstatus = value; }
        }
        public string ShippingAddress
        {
            get { return _shippingaddress; }
            set { _shippingaddress = value; }
        }

        public List<OrderItem> OrderItems
        {
            get { return _orderitems; }
            set { _orderitems = value; }
        }
        #endregion
    }
}