﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OrderManagementAPI.Models
{
    public class OrderItem
    {
        #region Private Variables
        private int _orderid;
        private int _orderitemid;
        private int _itemid;
        private int _quantity;        
        private string _name;        
        private string _weight;        
        private string _height;
        private string _image;
        #endregion

        #region Public Properties
        public int OrderId
        {
            get { return _orderid; }
            set { _orderid = value; }
        }
        public int OrderItemId
        {
            get { return _orderitemid; }
            set { _orderitemid = value; }
        }

        public int ItemId
        {
            get { return _itemid; }
            set { _itemid = value; }
        }
        public int Quantity
        {
            get { return _quantity; }
            set { _quantity = value; }
        }
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }
        public string Weight
        {
            get { return _weight; }
            set { _weight = value; }
        }
        public string Height
        {
            get { return _height; }
            set { _height = value; }
        }
        public string Image
        {
            get { return _image; }
            set { _image = value; }
        }
#endregion
    }
}